As discussed in the lectures

