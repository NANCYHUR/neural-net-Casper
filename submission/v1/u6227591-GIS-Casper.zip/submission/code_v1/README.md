Classifying Forest Supra-type from Augmented Satellite Data: Comparing Simple Neural Network, Bimodal and CasPer Techniques

COMP4660

u6227591
Jiawen He

files:
1. preprocessing.py  --- containing all preprocessing code, to be imported by other files
2. NN.py --- directly run this file to train and predict a neural network model on GIS dataset
3. CasPer.py --- directly run this file to train and predict on GIS using CasPer technique
4. CasPerBimodal.py --- directly run this file to train and predict on GIS using CasPer and Bimodal techniques